package polynomial;

/**
 * 
 * This class represent a polynomial, 
 * 
 */
public class Polynomial {
	protected int[] coefficients;
	protected int degree;
	
	public Polynomial() {
		// Default polynomial is 0
		coefficients = new int[] {0};
		degree = 0;
	}
		
	/* Construct the polynomial given it's coefficients */ 
	public Polynomial(int[] coeffs) {
		if(coeffs.length == 0) {
			coefficients = new int[] {0};
			degree = 0;
			return;
		}
		
		int deg = coeffs.length - 1;
		while (deg > 0 && coeffs[deg] == 0) { 
			deg--;
		}
	
		degree = deg;
		coefficients = new int[deg + 1];
			
		for(int i = 0; i <= deg; i++) {
			coefficients[i] = coeffs[i];
		}		
	}
	
	/* Multiply this polynomial by a constant factor */
	public void multiplyBy(int factor) {
		if(factor == 0) {
			coefficients = new int[] {0};
			degree = 0;
		}
		
		else {
			for(int i = 0; i <= degree; i++) {
				coefficients[i] *= factor;
			}
		}
	}
	
	/* Adds the polynomial p to this polynomial */
	public void add(Polynomial p) {
		int maxDegree = Math.max(this.degree, p.degree);
		
	    int[] newCoefficients = new int[maxDegree + 1];
	    
	    for (int i = 0; i <= this.degree; i++) {
	        newCoefficients[i] = this.coefficients[i];
	    }
	    
	    for (int i = 0; i <= p.degree; i++) {
	        newCoefficients[i] += p.coefficients[i];
	    }
	    
	    this.coefficients = newCoefficients;
	    
	    int newDegree = maxDegree;
	    while (newDegree > 0 && newCoefficients[newDegree] == 0) {
	        newDegree--;
	    }
	    this.degree = newDegree;
	}
	
	/* Subtract the polynomial p from this polynomial */
	public void subtract(Polynomial p) {
		int maxDegree = Math.max(this.degree, p.degree); 
	    int[] newCoefficients = new int[maxDegree + 1];

	    for (int i = 0; i <= this.degree; i++) {
	        newCoefficients[i] = this.coefficients[i];
	    }

	    for (int i = 0; i <= p.degree; i++) {
	        newCoefficients[i] -= p.coefficients[i];
	    }

	    this.coefficients = newCoefficients;

	    int newDegree = maxDegree;
	    while (newDegree > 0 && newCoefficients[newDegree] == 0) {
	        newDegree--;
	    }
	    this.degree = newDegree;
	}
	
	 /* Returns the polynomial derivative of this polynomial. 
	 * Does NOT change this polynomial */
	public Polynomial getDerivative() {
		if(degree == 0 || coefficients.length == 0)
			return new Polynomial(new int[] {0});
		
		int[] derivativeCoefficients = new int[degree];
		
		for(int i = 1; i <= degree; i++) {
			derivativeCoefficients[i - 1] = i * coefficients[i];
		}
		return new Polynomial(derivativeCoefficients); //STUB
	}
	
	/* Returns the value of the polynomial at a point */
	public double atPoint(float arg) {
		double result = 0;

	    for (int i = degree; i >= 0; i--) {
	        result = result * arg + coefficients[i];
	    }
	    
	    return result;
	}
	@Override
	public String toString() {
		if (degree == 0 && coefficients[0] == 0) {
	        return "0"; 
	    }

	    StringBuilder result = new StringBuilder();
	    
	    for (int i = degree; i >= 0; i--) {
	        int coef = coefficients[i];

	        if (coef == 0) continue;

	        if (result.length() > 0) {
	            result.append(coef > 0 ? " + " : " - ");
	        } else if (coef < 0) {
	            result.append("-");
	        }

	        if (Math.abs(coef) != 1 || i == 0) {
	            result.append(Math.abs(coef));
	        }

	        if (i > 0) {
	            result.append("x");
	            if (i > 1) {
	                result.append("^").append(i);
	            }
	        }
	    }

	    return result.toString();
	}
	
	public int getDegree() {
		return degree;
	}
	
	// Unfortunately, solving a general polynomial is not in our scope
	public double[] solve() {
		return null;
	}
	
}
